package com.example.first_app_busra

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val s1 = findViewById<EditText>(R.id.Sayi1)
        val s2 = findViewById<EditText>(R.id.Sayi2)
        val buton = findViewById<Button>(R.id.Toplab)
        val sonuc = findViewById<TextView>(R.id.textView)
        val toplamauygulamasi = findViewById<TextView>(R.id.textView2)
        buton.setOnClickListener{
            val sayi1 = s1.text.toString().toInt()
            val sayi2 = s2.text.toString().toInt()
            val toplam = sayi1 + sayi2
            sonuc.text=("Sonuc: "+toplam)
        }

    }
}